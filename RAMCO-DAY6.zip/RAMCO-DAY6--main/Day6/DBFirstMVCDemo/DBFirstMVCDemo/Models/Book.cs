﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DBFirstMVCDemo.Models
{
    public class Book
    {
        [Key]
        public int BookID { get; set; }
        public string BookTitle { get; set; }

        public float Price { get; set; }
    }

}
