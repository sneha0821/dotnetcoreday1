﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DBFirstMVCDemo.Models
{
    public class RamcoDB2 : DbContext
    {
        public RamcoDB2(DbContextOptions<RamcoDB2> options) : base(options)
        {

        }
        public DbSet<Book> Books { get; set; }
    }

}
