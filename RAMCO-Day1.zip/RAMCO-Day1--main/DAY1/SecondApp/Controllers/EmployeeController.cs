﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SecondApp.Models;

namespace SecondApp.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Page1()
        {
            return View();
        }

        //Get\
      
        public IActionResult ELogin()
        {
            return View();
        }

        //Post
        [HttpPost]
        public IActionResult ELogin(ELogin model)
        {
            if (model.UserName.Equals("Administrator") && model.Password.Equals("Admin@123"))
                return RedirectToAction("Page1");
            else
            {
                ViewBag.ErrorMessage = "Invalid Username or password";
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult Page2()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Page3()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Page3(Employee model)
        {

            return View();
        }
    }
}
