﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SecondApp.Models;


namespace SecondApp.Controllers
{
    public class HelloController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //    [HttpPost]
        //    public IActionResult Index(Calculator model,string Add,string Substract,string Multiply,string Divide)
        //    {
        //        if(!String.IsNullOrEmpty(Add))
        //        model.Result = model.Num1 + model.Num2;

        //        if (!String.IsNullOrEmpty(Substract))
        //            model.Result = model.Num1 - model.Num2;

        //        if (!String.IsNullOrEmpty(Multiply))
        //            model.Result = model.Num1 * model.Num2;

        //        if (!String.IsNullOrEmpty(Divide))
        //            model.Result = model.Num1 / model.Num2;

        //        return View(model);
        //    }

/*        [HttpPost]
        public IActionResult Index(Calculator model, string Calc)
        {
            switch (Calc)
            {
                case "Add":
                    model.Result = model.Num1 + model.Num2;
                    break;

                case "Substract":
                    model.Result = model.Num1 - model.Num2;
                    break;

                case "Multiply":
                    model.Result = model.Num1 * model.Num2;
                    break;

                case "Divide":
                    model.Result = model.Num1 / model.Num2;
                    break;


                default:
                    break;
            }
            return View(model);
        }

        [HttpPost]
        public IActionResult Addition(Calculator model)
        {
            model.Result = model.Num1 + model.Num2;
            return View("Index", model);
        }

        [HttpPost]
        public IActionResult Substract(Calculator model)
        {
            model.Result = model.Num1 - model.Num2;
            return View("Index",model);
        }

        [HttpPost]
        public IActionResult Multiply(Calculator model)
        {
            model.Result = model.Num1 * model.Num2;
            return View("Index", model);
        }

        [HttpPost]
        public IActionResult Divide(Calculator model)
        {
            model.Result = model.Num1 / model.Num2;
            return View("Index", model);
        }*/


    }
}

