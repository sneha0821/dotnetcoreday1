﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SecondApp.Models
{
    public class ELogin
    {
        [Display(Name="Enter User Name")]
        public string UserName { get; set; }
      
        [Display(Name = "Enter Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
