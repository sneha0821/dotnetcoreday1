﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SecondApp.Models
{
    public class Calculator
    {
        [Display(Name ="Enter a Number")]
        public int Num1 { get; set; }
        [Display(Name = "Enter a Number")]
        public int Num2 { get; set; }
        public int Result { get; set; }
    }
}
