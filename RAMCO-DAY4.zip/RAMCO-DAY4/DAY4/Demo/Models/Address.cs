﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo.Models
{
    public class Address
    {
        public String HNo { get; set; }
        public String City { get; set; }
        public String State { get; set; }
        public String PinCode { get; set; }

    }
}
