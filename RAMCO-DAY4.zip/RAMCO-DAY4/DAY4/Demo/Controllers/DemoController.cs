﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Demo.Models;

namespace Demo.Controllers
{
    public class DemoController : Controller
    {
        public IActionResult Index()
        {
            ViewData["Message1"] = "ViewData Message";
            TempData["Message2"] = "Tempdata Message";
         
            ViewBag.Message3 = "ViewBag Data";

            return View();
        }


        public IActionResult Page1()
        {
            ViewData["Message1"] = "Page1 ViewData Message";
            TempData["Message2"] = "Page1 Tempdata Message";

            ViewBag.Message3 = "Page1 ViewBag Data";

            return RedirectToAction("Page2");
        }


        public IActionResult Page2()
        {
          

            return View();
        }


        public IActionResult Page3()
        {
            Book obj = new Book() { BookId = 1, Title = "ABC", Price = 34.54f };

            ViewData["book1"] = obj;

            ViewBag.book2 = obj;


            return View();
        }


        public IActionResult Page4()
        {
            Book obj = new Book() { BookId = 1, Title = "ABC", Price = 34.54f };
            return View(obj);
        }
    }
}
